package com.crick.apis.entities;

public enum MatchStatus {

    COMPLETED   ,LIVE
}
