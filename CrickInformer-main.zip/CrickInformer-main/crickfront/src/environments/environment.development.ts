export const environment = {
    apiUrl:"http://localhost:8080"
};
